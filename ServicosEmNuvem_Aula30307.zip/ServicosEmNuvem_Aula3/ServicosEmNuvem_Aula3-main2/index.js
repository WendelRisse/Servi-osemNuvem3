document.getElementById('getWeatherBtn').addEventListener('click', function() {
    const city = document.getElementById('cityInput').value;
    if (!city) {
        document.getElementById('weatherInfo').innerHTML = '<p>Por favor, digite o nome de uma cidade.</p>';
        return;
    }

    const apiKey = 'c518b73599fd819ed4a703f56085a8f5';
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=pt_br`;

    console.log(`Fetching weather data for: ${city}`);
    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            if (data.cod === 200) {
                const weatherInfo = `
                    <h2>${data.name}, ${data.sys.country}</h2>
                    <p>Temperatura: ${data.main.temp}°C</p>
                    <p>Clima: ${data.weather[0].description}</p>
                `;
                document.getElementById('weatherInfo').innerHTML = weatherInfo;
            } else {
                document.getElementById('weatherInfo').innerHTML = `<p>Cidade não encontrada!</p>`;
            }
        })
        .catch(error => {
            console.error('Erro ao obter os dados:', error);
            document.getElementById('weatherInfo').innerHTML = `<p>Erro ao obter os dados.</p>`;
        });
});