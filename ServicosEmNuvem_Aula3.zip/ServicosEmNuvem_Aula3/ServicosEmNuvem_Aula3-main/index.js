// Chave de API da Open Exchange Rates
//const API_KEY = '277c552392fd4e44989f3c0fe1d93d91';

const http = require('http');
const https = require('https');

// Função para lidar com solicitações HTTP
function handleRequest(request, response) {
  // Preparar a solicitação para a API
  const apiRequest = https.request({
    hostname: 'open.er-api.com',
    path: request.url,
    method: request.method,
    headers: request.headers
  }, apiResponse => {
    // Passar os cabeçalhos da resposta da API para a resposta do servidor
    response.writeHead(apiResponse.statusCode, apiResponse.headers);

    // Encaminhar dados da API para a resposta do servidor
    apiResponse.on('data', chunk => {
      response.write(chunk);
    });

    // Finalizar resposta do servidor quando a resposta da API estiver completa
    apiResponse.on('end', () => {
      response.end();
    });
  });

  // Encaminhar dados da solicitação do cliente para a solicitação da API
  request.on('data', chunk => {
    apiRequest.write(chunk);
  });

  // Finalizar solicitação da API quando a solicitação do cliente estiver completa
  request.on('end', () => {
    apiRequest.end();
  });

  // Lidar com erros na solicitação da API
  apiRequest.on('error', error => {
    console.error('Erro na solicitação da API:', error);
    response.writeHead(500);
    response.end('Erro interno do servidor');
  });
}

// Criar servidor HTTP para lidar com solicitações
const server = http.createServer(handleRequest);

// Iniciar servidor na porta 3000
server.listen(3000, () => {
  console.log('Servidor proxy iniciado na porta 3000');
});





// Função para obter as taxas de câmbio da API
async function obterTaxas() {
  try {
    const response = await fetch(`https://openexchangerates.org/api/latest.json?app_id=277c552392fd4e44989f3c0fe1d93d91`);
    if (!response.ok) {
      throw new Error('Erro ao obter as taxas de câmbio');
    }
    const data = await response.json();
    return data.rates;
  } catch (error) {
    console.error(error);
    alert('Erro ao obter as taxas de câmbio. Por favor, tente novamente mais tarde.');
    return {};
  }
}

// Função para preencher as opções de moeda nos selects
async function preencherMoedas() {
  try {
    const response = await fetch('https://openexchangerates.org/api/latest.jsoncurrencies.jsonhistorical/2013-02-16.json');
    if (!response.ok) {
      throw new Error('Erro ao obter as moedas');
    }
    const currencies = await response.json();
    console.log(currencies); // Verifique os dados das moedas no console
    const fromSelect = document.getElementById('from');
    const toSelect = document.getElementById('to');
    for (const currencyCode in currencies) {
      const option = document.createElement('option');
      option.text = `${currencyCode} - ${currencies[currencyCode]}`;
      option.value = currencyCode;
      fromSelect.add(option.cloneNode(true));
      toSelect.add(option);
    }
  } catch (error) {
    console.error(error);
    alert('Erro ao obter as moedas. Por favor, tente novamente mais tarde.');
  }
}


// Função para converter a moeda
async function converterMoeda() {
  const amount = parseFloat(document.getElementById('amount').value);
  if (isNaN(amount)) {
    alert('Por favor, insira um valor numérico válido.');
    return;
  }

  const from = document.getElementById('from').value;
  const to = document.getElementById('to').value;
  
  const rates = await obterTaxas();
  const rate = rates[to];
  if (!rate) {
    alert('Não foi possível obter a taxa de câmbio para a moeda selecionada.');
    return;
  }
  
  const convertedAmount = amount * rate;

  document.getElementById('result').innerHTML = `${amount.toFixed(2)} ${from} equivale a ${convertedAmount.toFixed(2)} ${to}`;
}

// Preencher as opções de moeda ao carregar a página
window.onload = preencherMoedas;
